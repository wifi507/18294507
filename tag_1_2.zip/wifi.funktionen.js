/*
©2017, WIFI Wien
*/
var e = function( idElement ) {
	return document.getElementById( idElement );
}
